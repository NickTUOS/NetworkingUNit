﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;


namespace ClassChatClient
{

    public partial class Form1 : Form
    {
        BackgroundWorker ListenThread = new BackgroundWorker();

        public Form1()
        {
            InitializeComponent();

            ListenThread.DoWork += new DoWorkEventHandler(ListenerDoWork);
            ListenThread.RunWorkerAsync();
        }

        void ListenerDoWork(object sender, DoWorkEventArgs e)
        {
            IPAddress iPAddress = IPAddress.Loopback;// iPHostEntry.AddressList[0];


            IPEndPoint iPEndPoint = new IPEndPoint(iPAddress, 1235);

            Socket ServerSocket = new Socket(iPAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
            ServerSocket.Bind(iPEndPoint);
            ServerSocket.Listen(10);

            string data;
            byte[] bytes = new Byte[1024];

            while (true)
            {
                try
                {
                    Socket ClientSocket = ServerSocket.Accept();
                    data = null;

                    int bytseRec = ClientSocket.Receive(bytes);
                    data += Encoding.ASCII.GetString(bytes, 0, bytseRec);

                    //SetTextAppendNewLine(data);
                    ClientSocket.Shutdown(SocketShutdown.Both);
                    ClientSocket.Close();


                    SetText(data.ToString());
                }
                catch (Exception ex)
                {
                    rtbMessage.Text += ex.ToString();
                }
            }
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            try
            {
                IPAddress IP = IPAddress.Loopback;
                IPEndPoint remoteEP = new IPEndPoint(IP, 1234);

                Socket ClientSocket = new Socket(IP.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

                ClientSocket.Connect(remoteEP);

                byte[] data = Encoding.ASCII.GetBytes(rtbMessage.Text);
                ClientSocket.Send(data);
            }
            catch (Exception ex)
            {
                rtbRecived.Text += ex.ToString();
            }
        }

        delegate void SetRTBRecived(string Text);
        void SetText(string text)
        {
            if(this.rtbRecived.InvokeRequired)
            {
                SetRTBRecived setTextDelegate = new SetRTBRecived(SetText);
                this.Invoke(setTextDelegate, new object [] { text });
            }
            else
            {
                rtbRecived.Text += text;
            }
        }











        private void DragButton(object sender, DragEventArgs e)
        {

        }
    }
}
