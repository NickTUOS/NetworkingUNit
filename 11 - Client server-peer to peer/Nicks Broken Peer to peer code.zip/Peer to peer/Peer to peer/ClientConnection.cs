﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace Peer_to_peer
{
    class ClientConnection
    {
        IPAddress ipaddres;
        Socket socket;


        ClientConnection(long address, int port)
        {
            //ipaddres = new ip
        }
    }
}
