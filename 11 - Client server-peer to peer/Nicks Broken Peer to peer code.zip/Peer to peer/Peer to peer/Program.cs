﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net;

namespace Peer_to_peer
{
    class Program
    {
        static void Main(string[] args)
        {
            List<IPEndPoint> clientEndPoints = new List<IPEndPoint>();


            int serverPort = 1234;
            UdpClient Client = new UdpClient();
            Client.Client.Bind(new IPEndPoint(IPAddress.Any, serverPort));

            IPEndPoint from = new IPEndPoint(0, 0);

            Task.Run(() =>
            {
                while(true)
                {
                    var recivedData =Client.Receive(ref from);
                    //Console.WriteLine("DAta in: "+
                        //Encoding.UTF8.GetString(recivedData));

                    IPEndPoint tempNew = new IPEndPoint(from.Address, from.Port);
                    if (!clientEndPoints.Contains(tempNew))
                    {
                        clientEndPoints.Add(tempNew);
                        var data = Encoding.UTF8.GetBytes("Hello!");
                        Client.Send(data, data.Length, "255.255.255.255", serverPort);
                    }
                    Console.WriteLine("Broadcast recived from: "+ from.Address+":"+from.Port);
                }
            }
            );

            Task.Run(() =>
            {
                IPHostEntry ipHost = Dns.GetHostEntry(Dns.GetHostName());
                IPAddress MyIpV4 = null;
                for(int i=0; i<ipHost.AddressList.Length; i++)
                {
                    if(ipHost.AddressList[i].AddressFamily == AddressFamily.InterNetwork)
                    {
                        MyIpV4 = ipHost.AddressList[i];
                        break;
                    }
                }

                IPAddress ipserverTCP = new IPAddress(MyIpV4.Address);
                IPEndPoint serverTCPEndpoint = new IPEndPoint(MyIpV4.Address, 1234);
                Socket ServerSocket = new Socket(MyIpV4.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

                byte[] bytes = new Byte[1024];

                while (true)
                {
                    ServerSocket.Bind(serverTCPEndpoint);
                    ServerSocket.Listen(10);

                    Socket IncommingTCPSocket = ServerSocket.Accept();

                    IncommingTCPSocket.Receive(bytes);

                    Console.WriteLine("Data in: "+ Encoding.UTF8.GetString(bytes));

                    IncommingTCPSocket.Shutdown(SocketShutdown.Receive);
                    IncommingTCPSocket.Close();
                }

            });
            





            while (true)
            {
                //var data = Encoding.UTF8.GetBytes(Console.ReadLine());
                //Client.Send(data, data.Length, "255.255.255.255", serverPort);
            
                var data = Encoding.UTF8.GetBytes(Console.ReadLine());
                if(clientEndPoints.Count <=0)
                    Console.WriteLine("no connected clients");
                else
                {
                    foreach (var clientEndpoint in clientEndPoints)
                    {
                        Socket ClientSocket = new Socket(SocketType.Stream, ProtocolType.Tcp);
                        ClientSocket.Connect(clientEndpoint);
                        ClientSocket.Send(data);
                        //ClientSocket.Send(data, data.Length, clientEndpoint);
                        ClientSocket.Shutdown(SocketShutdown.Both);
                        ClientSocket.Close();
                    }
                }
            }


        }
    }
}
