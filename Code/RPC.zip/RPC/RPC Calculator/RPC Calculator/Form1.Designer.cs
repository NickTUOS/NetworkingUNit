﻿namespace RPC_Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rtbCalc = new System.Windows.Forms.RichTextBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.brn3 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btn0 = new System.Windows.Forms.Button();
            this.btnSub = new System.Windows.Forms.Button();
            this.btnPow = new System.Windows.Forms.Button();
            this.btnDiv = new System.Windows.Forms.Button();
            this.btnMult = new System.Windows.Forms.Button();
            this.flowLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // rtbCalc
            // 
            this.rtbCalc.Location = new System.Drawing.Point(7, 8);
            this.rtbCalc.Name = "rtbCalc";
            this.rtbCalc.Size = new System.Drawing.Size(427, 115);
            this.rtbCalc.TabIndex = 0;
            this.rtbCalc.Text = "";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.btn1);
            this.flowLayoutPanel1.Controls.Add(this.btn2);
            this.flowLayoutPanel1.Controls.Add(this.brn3);
            this.flowLayoutPanel1.Controls.Add(this.btn4);
            this.flowLayoutPanel1.Controls.Add(this.btn5);
            this.flowLayoutPanel1.Controls.Add(this.btn6);
            this.flowLayoutPanel1.Controls.Add(this.btn7);
            this.flowLayoutPanel1.Controls.Add(this.btn8);
            this.flowLayoutPanel1.Controls.Add(this.btn9);
            this.flowLayoutPanel1.Controls.Add(this.btnAdd);
            this.flowLayoutPanel1.Controls.Add(this.btn0);
            this.flowLayoutPanel1.Controls.Add(this.btnSub);
            this.flowLayoutPanel1.Controls.Add(this.btnPow);
            this.flowLayoutPanel1.Controls.Add(this.btnDiv);
            this.flowLayoutPanel1.Controls.Add(this.btnMult);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(13, 130);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(419, 344);
            this.flowLayoutPanel1.TabIndex = 1;
            // 
            // btn1
            // 
            this.btn1.Location = new System.Drawing.Point(3, 3);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(130, 52);
            this.btn1.TabIndex = 0;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.anyNumBtn_Click);
            // 
            // btn2
            // 
            this.btn2.Location = new System.Drawing.Point(139, 3);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(135, 52);
            this.btn2.TabIndex = 1;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Click += new System.EventHandler(this.anyNumBtn_Click);
            // 
            // brn3
            // 
            this.brn3.Location = new System.Drawing.Point(280, 3);
            this.brn3.Name = "brn3";
            this.brn3.Size = new System.Drawing.Size(127, 52);
            this.brn3.TabIndex = 2;
            this.brn3.Text = "3";
            this.brn3.UseVisualStyleBackColor = true;
            this.brn3.Click += new System.EventHandler(this.anyNumBtn_Click);
            // 
            // btn4
            // 
            this.btn4.Location = new System.Drawing.Point(3, 61);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(130, 52);
            this.btn4.TabIndex = 3;
            this.btn4.Text = "4";
            this.btn4.UseVisualStyleBackColor = true;
            this.btn4.Click += new System.EventHandler(this.anyNumBtn_Click);
            // 
            // btn5
            // 
            this.btn5.Location = new System.Drawing.Point(139, 61);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(135, 52);
            this.btn5.TabIndex = 4;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = true;
            this.btn5.Click += new System.EventHandler(this.anyNumBtn_Click);
            // 
            // btn6
            // 
            this.btn6.Location = new System.Drawing.Point(280, 61);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(127, 52);
            this.btn6.TabIndex = 5;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = true;
            this.btn6.Click += new System.EventHandler(this.anyNumBtn_Click);
            // 
            // btn7
            // 
            this.btn7.Location = new System.Drawing.Point(3, 119);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(130, 52);
            this.btn7.TabIndex = 6;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = true;
            this.btn7.Click += new System.EventHandler(this.anyNumBtn_Click);
            // 
            // btn8
            // 
            this.btn8.Location = new System.Drawing.Point(139, 119);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(135, 52);
            this.btn8.TabIndex = 7;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = true;
            this.btn8.Click += new System.EventHandler(this.anyNumBtn_Click);
            // 
            // btn9
            // 
            this.btn9.Location = new System.Drawing.Point(280, 119);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(127, 52);
            this.btn9.TabIndex = 8;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = true;
            this.btn9.Click += new System.EventHandler(this.anyNumBtn_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(3, 177);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(130, 52);
            this.btnAdd.TabIndex = 9;
            this.btnAdd.Text = "+";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btn0
            // 
            this.btn0.Location = new System.Drawing.Point(139, 177);
            this.btn0.Name = "btn0";
            this.btn0.Size = new System.Drawing.Size(135, 52);
            this.btn0.TabIndex = 10;
            this.btn0.Text = "0";
            this.btn0.UseVisualStyleBackColor = true;
            this.btn0.Click += new System.EventHandler(this.anyNumBtn_Click);
            // 
            // btnSub
            // 
            this.btnSub.Location = new System.Drawing.Point(280, 177);
            this.btnSub.Name = "btnSub";
            this.btnSub.Size = new System.Drawing.Size(127, 52);
            this.btnSub.TabIndex = 11;
            this.btnSub.Text = "-";
            this.btnSub.UseVisualStyleBackColor = true;
            this.btnSub.Click += new System.EventHandler(this.btnSub_Click);
            // 
            // btnPow
            // 
            this.btnPow.Location = new System.Drawing.Point(3, 235);
            this.btnPow.Name = "btnPow";
            this.btnPow.Size = new System.Drawing.Size(130, 52);
            this.btnPow.TabIndex = 12;
            this.btnPow.Text = "Pow";
            this.btnPow.UseVisualStyleBackColor = true;
            this.btnPow.Click += new System.EventHandler(this.btnPow_Click);
            // 
            // btnDiv
            // 
            this.btnDiv.Location = new System.Drawing.Point(139, 235);
            this.btnDiv.Name = "btnDiv";
            this.btnDiv.Size = new System.Drawing.Size(135, 52);
            this.btnDiv.TabIndex = 13;
            this.btnDiv.Text = "/";
            this.btnDiv.UseVisualStyleBackColor = true;
            this.btnDiv.Click += new System.EventHandler(this.btnDiv_Click);
            // 
            // btnMult
            // 
            this.btnMult.Location = new System.Drawing.Point(280, 235);
            this.btnMult.Name = "btnMult";
            this.btnMult.Size = new System.Drawing.Size(127, 52);
            this.btnMult.TabIndex = 14;
            this.btnMult.Text = "*";
            this.btnMult.UseVisualStyleBackColor = true;
            this.btnMult.Click += new System.EventHandler(this.btnMult_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(444, 486);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.rtbCalc);
            this.Name = "Form1";
            this.Text = "Form1";
            this.flowLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtbCalc;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button brn3;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btn0;
        private System.Windows.Forms.Button btnSub;
        private System.Windows.Forms.Button btnPow;
        private System.Windows.Forms.Button btnDiv;
        private System.Windows.Forms.Button btnMult;
    }
}

