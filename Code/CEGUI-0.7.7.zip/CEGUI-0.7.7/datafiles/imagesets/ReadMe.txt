The images in this directory were obtained from various sources...

GPN-2000-001437.tga		- From GRIN (http://grin.hq.nasa.gov/)
TaharezLook.tga			- Original Taharez imagery created by Lars "Taharez" Rinde.
WindowsLook.tga			- Windows look imagery created by Paul "CrazyEddie" Turner.
vanilla.tga				- Original "Vanilla GUI" imagery created by Shane Parker, used with permission.
